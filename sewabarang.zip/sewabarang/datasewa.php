<script type="text/javascript">
	function hapus_jurnal(idjurnal){
		var idjurnalnya = idjurnal;
		
		var tanya = confirm("Apakah Yakin Ingin Menghapus Data Jurnal?");
		if (!tanya) {
		  
		}else{
		  // proceed with form submission
		  $.ajax({
			url: 'proses.php?aksi=hapus_jurnal_langsung',
			type: 'POST',
			data: {
				'idjurnal' : idjurnalnya,
			},
			success: function(hasil){
				alert('berhasil dihapus');
				$('#jurnal_'+idjurnalnya).remove();
			}
		  });
		 }
		};
</script>
<html>
<head><title>Data Jurnal</title>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>



<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">    
    <a class="navbar-brand" href="#">Jurnal Online</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mr-auto">
              <li class="nav-item">
          <a class="nav-link" href="dash.php">Dashboard</a>
        </li>
                <li class="nav-item">
          <a class="nav-link" href="jurnal.php">Jurnal</a>
        </li>
              </ul>
      <a href="?q=logout" onclick='return confirm("Apakah Yakin Ingin Logout?")' class="btn btn-danger">Keluar</a>
    </div>
   </div>
  </nav>   <div class="container" style="margin-top:2%">
	<div class="card mx-auto">
     <div class="card-header">
	 	<div class="row">
		   <div class="col-xs-6 col-sm-6">
	   		<h2>Data Jurnal</h2>
			   Sistem Informasi Persewaan Barang - Anindi<h6></h6>		   </div>
		   <!-- awal -->
			 
				<div class="col-xs-6 col-sm-6">
				<div class="input-group">
					<input type="text" class="form-control" placeholder="Pencarian..." id="keyword">
					
					<span class="input-group-btn">
					<button class="btn btn-primary" type="button" id="btn-cari">SEARCH</button>
					<a href="" class="btn btn-warning">RESET</a>
					</span>
				</div>
				</div>
			
		   <!-- akhir -->
	    </div>
	 </div>
		<div class="card-body">
			<!-- <a href="tambah.php" class="btn btn-primary">Tambah Data Jurnal</a> -->
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Tambah Data Jurnal</button>
			<!-- Modal tambah data-->
	<div id="myModal" class="modal fade" role="dialog" data-backdrop="static">
		<div class="modal-dialog">
			<!-- konten modal-->
			<div class="modal-content">
				<!-- heading modal -->
				<div class="modal-header">
					<h4 class="modal-title">Tambah Data Jurnal</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<!-- body modal -->
				<div class="modal-body">
				<form action="" method="post">
					<div class="form-group">
						<label for="progres">Persewaan</label>
						<textarea class="form-control" name="progres" id="progres" rows="4" required></textarea>
					</div>
					<div class="row" style="margin-left:83%">
						<button class="btn btn-primary" name="input" type="submit">Simpan</button>
					</div>
				</form>
				</div>
				<!-- footer modal -->
				<div class="modal-footer">
					<!-- <button type="button" class="btn btn-primary" data-dismiss="modal">Simpan</button> -->
				</div>
			</div>
		</div>
	</div>
	<!-- akhir modal tambah -->
	<div class="table-responsive" id="jurnal-table">
	<table class="table table-striped">
	<hr>
		<thead>
		<tr>
			<th>No</th>
			<th>Tanggal Jurnal</th>
			<th>Progres</th>
			<th>Aksi</th>
		</tr>
		</thead>
		<tbody>
				<tr>
		 <td>1</td>
		 <td>2020-08-13 16:06:50</td>
		 		 <td>Membuat tampilan login</td>
		 <td>
			<a class="btn btn-danger" href="proses.php?aksi=hapus_jurnal&idjurnal=NDQ="onclick='return confirm("Apakah Yakin Ingin Menghapus Data Jurnal?")'>Hapus</a>
		</td>	
				<tr>
		 <td>2</td>
		 <td>2020-08-12 09:28:43</td>
		 		 <td>Membuat tampilan user dan tambah data</td>
		 <td>
			<a class="btn btn-danger" href="proses.php?aksi=hapus_jurnal&idjurnal=MjY="onclick='return confirm("Apakah Yakin Ingin Menghapus Data Jurnal?")'>Hapus</a>
		</td>	
				<tr>
		 <td>3</td>
		 <td>2020-08-10 09:11:38</td>
		 		 <td>Konsultasi rancangan tabel</td>
		 <td>
			<a class="btn btn-danger" href="proses.php?aksi=hapus_jurnal&idjurnal=MTE="onclick='return confirm("Apakah Yakin Ingin Menghapus Data Jurnal?")'>Hapus</a>
		</td>	
				</tr>
		</tbody>
	</table>
	<nav>
		<ul class="pagination justify-content-center">
			<li class="page-item">
				<a class="page-link" >Previous</a>
			</li>
			 
				<li class="page-item"><a class="page-link" href="?halaman=1">1</a></li>
								
			<li class="page-item">
				<a  class="page-link" >Next</a>
			</li>
		</ul>
	</nav>
   </div>
	
	</div>
	</div>
	
	</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('#btn-cari').on('click', function(){
		var keyword = $('#keyword').val();
		var jenis_user_ = "U";
		var iduser_ = "6";
		if (keyword == 0 ) {
		  alert('kosong!');
		}else{
		  // proceed with form submission
		  $.ajax({
			url: 'proses.php?aksi=cari_jurnal',
			type: 'POST',
			data: {
				'keyword' : keyword,
				'jenis_user' : jenis_user_,
				'iduser' : iduser_,
				'bentuk' : 'tabel',
			},
			success: function(hasil){
				
				$('#jurnal-table').html(hasil);
			}
		  });
		 }
		});
		
	});

</script>
</body>
</html>