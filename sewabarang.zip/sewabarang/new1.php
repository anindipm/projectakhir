<html>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<script type= "text/javascript" src="assets/js/bootstrap.min.js"></script> 
	<script type ="text/javascript" src="assets/js/bootstrap.js"></script>

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="hal_utama.php">Home</a></li>
    <li class="breadcrumb-item"><a href="tambah_pelanggan.php">Daftar</a></li>
    <li class="breadcrumb-item"><a href="pelanggan.php">Data Pelanggan</a></li>
    <li class="breadcrumb-item"><a href="barang.php">Data Barang</a></li>
    <li class="breadcrumb-item active"><a href="penyewaan.php">Data Sewa</li>
  </ol>
</nav>
  <div class="container-fluid" style="margin-top:1%">
	<div class="card mx-auto border-info">
     <div class="card-header ">
	 	<div class="row">
		   <div class="col-xs-6 col-sm-6">
	   		<h2>Data Barang</h2>
			    Barang<h6></h6>		   </div>
		   <!-- awal -->
			 
	    </div>
	 </div>
<body>
	<div class="container-fluid" style="margin-top">
		<div class="card-body">
		
		<div class="table-responsive">
		<table class="table table-striped">
			
		</div>
	</div>
	</div>
</body>
</html>