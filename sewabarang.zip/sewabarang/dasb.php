<?php

	session_start();
	include "koneksi.php";
	$db = new database();
	$data_pelanggan = $db->tampil_pelanggan();
	
?>
<html>
<head><title>Data Persewaan</title>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
  <div class="container" >  
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mr-auto">
              <li class="nav-item">
          <a class="nav-link" href="barang.php">Data Barang</a>
        </li>
                <li class="nav-item">
          <a class="nav-link" href="penyewaan.php">Data Persewaan</a>
        </li>
              </ul>
    </div>
   </div>
  </nav>   
  <div class="container-fluid" style="margin-top:2%">
	<div class="card mx-auto">
     <div class="card-header">
	 	<div class="row">
		   <div class="col-xs-6 col-sm-6">
	   		<h2>Halaman Utama</h2>
			   Data Penyewa<h6></h6>		   </div>
		   <!-- awal -->
			 
	    </div>
	 </div>
<body>
	<div class="container-fluid" style="margin-top">
		<div class="card-body">
		
		<div class="table-responsive">
		<table class="table table-striped">

			<?php
				$batas = 5;
				$halaman = isset($_GET['halaman'])?(int)$_GET['halaman'] : 1;
				$halaman_awal = ($halaman>1) ? ($halaman * $batas) - $batas : 0;
				$previous = $halaman - 1;
				$next = $halaman + 1;
				$data = $db->tampil_pelanggan();
				$jumlah_data = $data;
				$total_halaman = ceil($jumlah_data / $batas);
				$data_pelanggan = $db->tampil_pelanggan_paging($halaman_awal,$batas);
				$nomor = $halaman_awal+1;
				if($jumlah_data!=0){
					include "view_dash.php";
				}else{
					echo "<br><br><h3>Data Anda Kosong</h3>";
				}
			?>
		</div>
	</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<br></br>
</body>		<ul class="pagination justify-content-center">
			<li class="page-item">
				<a class="page-link" >Previous</a>
			</li>
			 
				<li class="page-item"><a class="page-link" href="?halaman=1">1</a></li>
								
			<li class="page-item">
				<a  class="page-link" >Next</a>
			</li>
		</ul>
	</nav>
	</div>
	</div>
	
	</div>
</body>
</html>