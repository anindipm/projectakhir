<html>
<head><title>Halaman Utama</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<script type= "text/javascript" src="assets/js/bootstrap.min.js"></script> 
	<script type ="text/javascript" src="assets/js/bootstrap.js"></script>

</head>

<body>
    <header class="navbar navbar-expand-lg navbar-dark bg-dark flex-column flex-md-row bd-navbar">

		<div class="container" >  
		<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav mr-auto">

		<div class="navbar-nav-scroll">
			<ul class="navbar-nav bd-navbar-nav flex-row">
				<li class="nav-item">
					<a class="nav-link active" href="/" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Home'); ">HOME</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="tambah_pelanggan.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Daftar');">DAFTAR</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="users.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'User');">USER</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="pelanggan.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Pelanggan');">DATA PELANGGAN</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="barang.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Barang');">DATA BARANG</a>
				</li>
				<li class="nav-item">
				<a class="nav-link " href="penyewaan.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Persewaan');">DATA PERSEWAAN</a>
				</li>
			</ul>
		</div>
</header>
	<style>
	body
	{
		background-image: url('gambar1.jpeg');
		background-repeat: no-repeat;
		background-size: cover;
	}
	</style>
</body>
</html>