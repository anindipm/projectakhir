<?php
include "koneksi.php";
$db = new database();

$aksi = $_GET['aksi'];
	if ($aksi == "tambah_data"){
		$db->tambah_data($_POST ['nama_barang'],$_POST['tgl_sewa'],$_POST['total_sewa']);
			header ("location:data.php");
	}else if($aksi == "hapus_data"){
		$db->hapus_data($_GET['kode_barang']);
			header ("location:data.php");
	}
?>