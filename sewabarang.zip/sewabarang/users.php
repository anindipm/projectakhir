<?php

	session_start();
	include "koneksi.php";
	$db = new database();
	$data_user = $db->tampil_user();
	
?>
<html>
<head><title>Users</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<script type= "text/javascript" src="assets/js/bootstrap.min.js"></script> 
	<script type ="text/javascript" src="assets/js/bootstrap.js"></script>

</head>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark flex-column flex-md-row bd-navbar">		
		<div class="container navbar-collapse">    
		<a class="navbar-brand" href="#"></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="nav-link " href="halaman_utama.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Home'); ">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="data_camera.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Camera');">Camera</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="data_accesories.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Accessories');">Accessories</a>
				</li>
				<li class="nav-item">
					<a class="nav-link active" href="users.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'User');">User</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="pelanggan.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Pelanggan');">Pelanggan</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="barang.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Barang');">Barang</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="penyewaan.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Persewaan');">Persewaan</a>
				</li>

            </ul>
		</div>
		</div>
	</nav>	

	<style>
	body
	{
		background-image: url('gambar3.jpg');
		background-repeat: no-repeat;
		background-size: cover;
	}
	</style>
	
	<div class="container" style="margin-top:3%">
	<div class="card mx-auto border-info">
    <div class="card-header">
	 	<div class="row">
		<br/>
			<div class="col-xs-6 col-sm-6">
	   		<h2>Data User</h2>
		</div>
	    </div>
	 </div>

<body>
	<div class="container-fluid" style="margin-top">
		<div class="card-body">
		<div class="table-responsive">

		<?php
			$batas = 4;
			$halaman = isset($_GET['halaman'])?(int)$_GET['halaman'] : 1;
			$halaman_awal = ($halaman>1) ? ($halaman * $batas) - $batas : 0;
			$previous = $halaman - 1;
			$next = $halaman + 1;
			$data = $db->tampil_user();
			$jumlah_data = $data;
			$total_halaman = ceil($jumlah_data / $batas);
			$data_users = $db->tampil_users_paging($halaman_awal,$batas);
			$nomor = $halaman_awal+1;
			if($jumlah_data!=0){
				include "view_users.php";
				}else{
				echo "<br><br><h3>Data Anda Kosong</h3>";
				}
			?>
		</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

</body>
</html>