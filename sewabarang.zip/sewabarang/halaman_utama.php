<?php

	session_start();
	include "koneksi.php";
	$db = new database();
	$data_users = $db->tampil_user();
	$iduser = $_SESSION['iduser'];
	$username = $_SESSION['username'];
	
	if(!isset($_SESSION['is_login'])){
		header("location:login.php");
	
	}
	if(isset($_GET['q'])){
		$db->logout();
		header("location:login.php");
	}
	
?>
<html>
<head>
  <title>Sewa Camera</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<script type= "text/javascript" src="assets/js/bootstrap.min.js"></script> 
	<script type ="text/javascript" src="assets/js/bootstrap.js"></script>
 
</head>
<body>
	<header class="navbar navbar-expand-lg navbar-dark bg-dark flex-column flex-md-row bd-navbar">
		<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav mr-auto">
		
		<div class="navbar-nav-scroll">
			<ul class="navbar-nav bd-navbar-nav flex-row">
				<li class="nav-item">
					<a class="nav-link active" href="/" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Home'); ">HOME</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="data_camera.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Camera');">Camera</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="data_accesories.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Accessories');">Accessories</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="users.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'User');">User</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="pelanggan.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Pelanggan');">Pelanggan</a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="barang.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Barang');">Barang</a>
				</li>
				<li class="nav-item">
				<a class="nav-link " href="penyewaan.php" onclick="ga('send', 'event', 'Navbar', 'Community links', 'Persewaan');">Persewaan</a>
				</li>
			</ul>
		</div>
		</ul>
			<a href="?q=logout" onclick='return confirm("Apakah Yakin Ingin Logout?")' class="btn btn-outline-danger">Keluar</a>
		</div>
	</header>

	<style>
	body
	{
		background-image: url('gambar1.jpg');
		background-repeat: no-repeat;
		background-size: cover;
	}
	</style>
	
	<main>
		<div class="container">
			<div class="row pt-5">
				<div class="col text-center text-white">
					<br><br>
					<br><br>
					<br><br>
					<br><br>
					<br/>
					<h1>Selamat Datang, admin</h1>
				</div>
			</div>
		</div>
	</main>
</body>
</html>