<div class="container-fluid">
<div class="table-responsive">
<div class= "col-md-">
		<table class="table table-striped">
		
		<hr>
			<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Alamat</th>
				<th>Email</th>
				<th>No. Telepon</th>
				<th>Tipe</th>
				<th>Aksi</th>
			</tr>
			</thead>
			<tbody>
			
			<?php
				$no=1;
				foreach($data_pelanggan as $row){
			?>
						<?php
							$cektype = $row['type'];
							if($cektype=='A'){
								$typenya="Admin";
							}else{
								$typenya="Pelanggan";
							}
							?>
					<tr>
						<td><?php echo $no; ?></td>
						<td><?php echo $row['username']; ?></td>
						<td><?php echo $row['alamat']; ?></td>
						<td><?php echo $row['email']; ?></td>
						<td><?php echo $row['telepon']; ?></td>
						<td><?php echo $typenya; ?></td>
						<td>
						<a class="btn btn-info" a href="data.php?aksi=data&idpelanggan=<?php echo $row['idpelanggan']; ?>">Lihat Data</a>
							<?php
								$no++;
								}
							?>
						</td>
						
						</tr>
				</tbody>
			</table>
			
		</div>
		</div>
		