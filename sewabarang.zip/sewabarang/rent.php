
<!DOCTYPE html>
<html lang="en">

	<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

        
    <meta property="og:image" content="https://www.pondoklensa.com/app/Web/Assets/apps/images/touch/og-image-200x200.png" /> 
    <title>PONDOK LENSA | SEWA KAMERA | SEWA LENSA | JAKARTA - BANDUNG - BALI</title>

    <!-- Disable tap highlight on IE -->
    <meta name="msapplication-tap-highlight" content="no">

    <!-- Web Application Manifest -->
    <link rel="manifest" href="https://www.pondoklensa.com/app/Web/Assets/apps/js/manifest.json">
    
    <!-- Web CSRF TOKEN-->
    <meta name="csrf-token" content="pfj86HrU0X0a8wwop6zp7n3gRAgZgNBkBHtT5RwM">
        <meta name="keywords" content="sewakamera, rental kamera, sewa kamera murah, kamera canon, EOS 5D mark III, kamera nikon, DSLR, handycam, sewa lensa, rental lensa, tokina, tamron, sigma, leica, zeiss, sewa kodak, rental lampu studio, rental printer foto, kenko teleplus pro, bowens, flash, tripod, pembersihan lensa, sensor cleaning, kostum foto, kamera medium format, phase one, digital back, paket lebaran, printer kodak 6850, panasonic hdc-mdh1, camcorder">
    <meta name="description" content="Situs rental kamera terlengkap yang menyewakan peralatan fotografi dan video shooting di Bandung dan Bali. Sewa kamera DSLR Canon, DSLR Nikon, kamera IR, handycam, camcorder, kamera underwater, Canon EF, Canon EF-S, Nikon AF, Nikon AF-S, Tokina, Tamron, Sigma, flash Canon, flash Nikon, aksesori filter, tripod dan battery grip.">
    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="application-name" content="Pondok Lensa">
    <link rel="icon" sizes="192x192" href="https://www.pondoklensa.com/app/Web/Assets/apps/images/touch/chrome-touch-icon-192x192.png">

    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Web Starter Kit">
    <link rel="apple-touch-icon" href="https://www.pondoklensa.com/app/Web/Assets/apps/images/touch/apple-touch-icon.png">

    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="https://www.pondoklensa.com/app/Web/Assets/apps/images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#000000">

    <!-- Color the status bar on mobile devices -->
    <meta name="theme-color" content="#000000">

    <!-- Fonts & Icons -->
    <!-- <link href="https://fonts.googleapis.com/css?family=Montserrat:500,700|Open+Sans:400,700" rel="stylesheet"> -->
    <link href="https://www.pondoklensa.com/app/Web/Assets/vendors/font-awesome-4.7.0/css/font-awesome.css" rel="stylesheet" >
    <link href="https://www.pondoklensa.com/app/Web/Assets/apps/css/icon_font.css" rel="stylesheet">

    <!-- Vendor Styles-->
    <link href="https://www.pondoklensa.com/app/Web/Assets/apps/css/vendors.css" rel="stylesheet">
    <link href="https://www.pondoklensa.com/app/Web/Assets/vendors/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet">
    <link href="https://www.pondoklensa.com/app/Web/Assets/vendors/fixed-header/css/defaultTheme.css" rel="stylesheet">
    <!-- <link href="https://www.pondoklensa.com/app/Web/Assets/vendors/pnotify/pnotify.custom.min.css" rel="stylesheet"> -->

    <!-- Main styles -->
    <link href="https://www.pondoklensa.com/app/Web/Assets/apps/css/app.css?v1.4.1" rel="stylesheet">
    <link href="https://www.pondoklensa.com/app/Web/Assets/apps/css/mb.css?v1.6.6" rel="stylesheet">
    <link href="https://www.pondoklensa.com/app/Web/Assets/vendors/blockUI/blockUI.css" rel="stylesheet">

                
    <!-- Head Libs -->
    <script src="https://www.pondoklensa.com/app/Web/Assets/vendors/modernizr/modernizr-custom.js"></script>
</head>		<body>
		<div id="app" v-cloak>
	        <header id="header" class="header">
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                                                                        <a href="mailto:pondoklensa@gmail.com" target="_top" class="contact-link"><i class="lnr lnr-envelope"></i> pondoklensa@gmail.com</a>
                                            
                                                                        <div class="fb-like" data-href="https://www.facebook.com/PondokLensa" data-layout="button_count" data-action="like" data-size="small" data-show-faces="false" data-share="false"></div>
                                                            </div>
                <div class="col-sm-8 text-right">
                    <a target="_blank" href="https://api.whatsapp.com/send?phone=6283899992121&text=&source=&data=" class="button--default button--x-small chat header-wa-link-3"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">Kritik &amp; Saran</a>
                    <!-- <a @click="handleOpenChat" class="button--default button--x-small chat"><i class="lnr lnr-bubble"></i>Ayo Chat Dengan Kami</a> -->

                    <a href="https://goo.gl/9VxLTU" target="_blank" class="button--default button--x-small chat header-wa-link-0"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">Bandung</a><a href="https://goo.gl/QLnSs7" target="_blank" class="button--default button--x-small chat header-wa-link-1"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">Bali</a><a href="https://bit.ly/3nSl62F" target="_blank" class="button--default button--x-small chat header-wa-link-2"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">Jakarta</a>                    <span class="divider"></span>

                                        <div class="location dropdown">
                        <button class="dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                            <i class="lnr lnr-map-marker"></i> Lokasi
                            <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                                                                                <li><a href="https://www.pondoklensa.com/contact-us/1">Bandung</a></li>
                                                                    <li><a href="https://www.pondoklensa.com/contact-us/2">Bali</a></li>
                                                                    <li><a href="https://www.pondoklensa.com/contact-us/3">Jakarta</a></li>
                                                            
                             
                        </ul>
                    </div>
                                        <span class="divider"></span>
                    <ul class="language">
                        
                        <li><a @click="handleChangeLanguage('en')" > <img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/lang-en.png" alt=""></a></li>
                        <li><a @click="handleChangeLanguage('id')" class=is-active> <img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/lang-id.png" alt=""></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="main-header">
    <div class="container">
        <div class="row row--flex main-header__body">
            <div class="col">
                <div id="main-menu">
                    <a href="#" class="menu-action--open"><i class="lnr lnr-menu"></i></a>
                    <div class="menu-wrapper">
                        <div class="menu-header">
                            <a href="#" class="logo">
                                <img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/mobile-logo.png" alt="">
                            </a>
                            <a href="#" class="menu-action--close"><i class="lnr lnr-cross"></i></a>
                        </div>
                        <ul class="menu">
                            <li class="menu__item is-hidden-touch"><a class="menu__link" href="https://www.pondoklensa.com/simulation">Rental Simulation</a></li>
<li class="menu__item is-hidden-touch"><a class="menu__link" href="https://www.pondoklensa.com/price-list">Price List</a></li>
<li class="menu__item is-hidden-touch"><a class="menu__link" href="https://www.pondoklensa.com/search/new">New Product</a></li>
<li class="menu__item has-children">
<a class="menu__link" href="#">
<i class="lnr lnr-menu is-desktop-only"></i> <span class="is-touch">Main Menu</span>
</a><ul class="submenu">
<li>
<ul>
<li class="is-touch"><a href="https://www.pondoklensa.com/simulation">Rental Simulation</a></li>
<li class="is-touch"><a href="https://www.pondoklensa.com/price-list">Price List</a></li>
<li class="is-touch"><a href="https://www.pondoklensa.com/search/new">New Product</a></li>
<li><a href="https://www.pondoklensa.com/why-us">Why Us</a></li>
<li><a href="https://www.pondoklensa.com/contact-us/1">Contact Us</a></li>
<li><a href="https://www.pondoklensa.com/testimonial">Testimonial</a></li>
<li><a href="https://www.pondoklensa.com/profile">Member Area</a></li>
<li><a href="https://www.pondoklensa.com/item-request">Item Request</a></li>
<li><a href="https://www.pondoklensa.com/how-to-rent">How to Rent</a></li>
</ul>
</li>
<li>
<ul>
<li class="is-touch"><a href="https://www.pondoklensa.com/simulation">Rental Simulation</a></li>
<li class="is-touch"><a href="https://www.pondoklensa.com/price-list">Price List</a></li>
<li class="is-touch"><a href="https://www.pondoklensa.com/search/new">New Product</a></li>
<li><a href="https://www.pondoklensa.com/rental-agreement">Rental Agreement</a></li>
<li><a href="https://www.pondoklensa.com/favorite">Favorite</a></li>
</ul>
</li>
</ul>
</li>
<li class="menu__item has-children is-touch">
<a class="menu__link" href="#">
Category
</a>
<ul class="submenu">
<li><a data-id="" data-href="" href="#" class="search-all">Browse All</a></li>
<li><a data-id="" data-href="" href="https://www.pondoklensa.com/search/new" class="">What's New</a></li>
<li><a data-id="MjAxNzA1MTAwOTMzMzU2NTUwMTI1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTAwOTMzMzU2NTUwMTI1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTAwOTMzMzU2NTUwMTI1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Camera</a></li>
<li><a data-id="MjAxNzA1MTAwOTMzMzU2NTcwMTUxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTAwOTMzMzU2NTcwMTUxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTAwOTMzMzU2NTcwMTUxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Tripods</a></li>
<li><a data-id="MjAxNzA1MTExNTEyNTUxNTkwMTIyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNTkwMTIyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNTkwMTIyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Lenses</a></li>
<li><a data-id="MjAxNzA1MTExNTEyNTUxNjIwMTUzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjIwMTUzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjIwMTUzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Lighting</a></li>
<li><a data-id="MjAxNzA1MTExNTEyNTUxNjMwMTM0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjMwMTM0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjMwMTM0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Video Gear</a></li>
<li><a data-id="MjAxNzA1MTExNTEyNTUxNjUwMTI0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjUwMTI0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjUwMTI0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Audio</a></li>
<li><a data-id="MjAxNzA1MTExNTEyNTUxNjYwMTEzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjYwMTEzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjYwMTEzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Accessories</a></li>
<li><a data-id="MjAxNzA1MTExNTEyNTUxNjgwMTg0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" data-href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjgwMTg0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" href="https://www.pondoklensa.com/search/tag/MjAxNzA1MTExNTEyNTUxNjgwMTg0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==" class="reset-filter">Multimedia</a></li>
<li><a data-id="" data-href="" href="https://www.pondoklensa.com/item-request" class="">Item Request</a></li>
</ul>
</li>

                            <li class="menu__item is-touch"><a class="menu__link" @click="handleOpenChat">Chat Dengan Kami</a></li>
                            <li class="menu__item has-children is-touch">
                                <a class="menu__link" href="#">Bahasa</a>
                                <ul class="submenu">
                                    
                                    <li><a @click="handleChangeLanguage('en')" >English</a></li>
                                    <li><a @click="handleChangeLanguage('id')" class=is-active>Indonesia</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col col--align-center">
                <a href="https://www.pondoklensa.com" class="logo">
                    <img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/logo.png" alt="">
                </a>
            </div>
            <div class="col col--align-right">
                <div class="search-wrapper">
                                        <div id="search" class="search"  data-search-configs='{&quot;endpoint&quot;:&quot;https:\/\/www.pondoklensa.com\/search-header&quot;,&quot;placeholder&quot;:&quot;Cari Disini...&quot;,&quot;id&quot;:&quot;search_keyword&quot;,&quot;method&quot;:&quot;POST&quot;,&quot;data&quot;:{&quot;location&quot;:{&quot;countryName&quot;:&quot;Indonesia&quot;,&quot;countryCode&quot;:&quot;ID&quot;,&quot;regionCode&quot;:&quot;&quot;,&quot;regionName&quot;:&quot;&quot;,&quot;cityName&quot;:&quot;Yogyakarta&quot;,&quot;zipCode&quot;:&quot;&quot;,&quot;isoCode&quot;:&quot;&quot;,&quot;postalCode&quot;:null,&quot;latitude&quot;:&quot;-7.8014&quot;,&quot;longitude&quot;:&quot;110.3647&quot;,&quot;metroCode&quot;:&quot;&quot;,&quot;areaCode&quot;:&quot;&quot;,&quot;driver&quot;:&quot;Stevebauman\\Location\\Drivers\\MaxMind&quot;}}}'></div>
                </div>
                <div class="divider is-hidden-touch"></div>
                                <div class="dropdown user">
                    <a class="dropdown-toggle" href="#" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        <i class="lnr lnr-enter"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu3">
                            <li><a href="https://www.pondoklensa.com/sign-in" data-callback="ZnJuZXB1L2dudC9ad05rQW1OMVpHTmpCR1ptWm1IMkFHSGpaR1YxSnprbnF6U2tJek1VblRJdXF6UzBJelNhTHljYk1hSUpNMk1PTHpxQkVhV2pNS1dhR1RXYkVhSXZuVXlrSlVXbExqPT1abFp2YXFWZkdoZWF2YXRWYWdiWmhmdVZnZkFiZ05GcnBlcmdMYmhGdWJoeXFYcnJj" class="callback">Masuk</a></li>
                            <li><a href="https://www.pondoklensa.com/sign-up" data-callback="ZnJuZXB1L2dudC9ad05rQW1OMVpHTmpCR1ptWm1IMkFHSGpaR1YxSnprbnF6U2tJek1VblRJdXF6UzBJelNhTHljYk1hSUpNMk1PTHpxQkVhV2pNS1dhR1RXYkVhSXZuVXlrSlVXbExqPT1abFp2YXFWZkdoZWF2YXRWYWdiWmhmdVZnZkFiZ05GcnBlcmdMYmhGdWJoeXFYcnJj" class="callback">Daftar</a></li>
                    </ul>
                </div>
                
                <!-- <div class="dropdown user">
                    <a class="dropdown-toggle" href="#" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        <i class="lnr lnr-user"></i>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu3">
                                                    <li><a href="https://www.pondoklensa.com/sign-in" data-callback="ZnJuZXB1L2dudC9ad05rQW1OMVpHTmpCR1ptWm1IMkFHSGpaR1YxSnprbnF6U2tJek1VblRJdXF6UzBJelNhTHljYk1hSUpNMk1PTHpxQkVhV2pNS1dhR1RXYkVhSXZuVXlrSlVXbExqPT1abFp2YXFWZkdoZWF2YXRWYWdiWmhmdVZnZkFiZ05GcnBlcmdMYmhGdWJoeXFYcnJj" class="callback">Masuk</a></li>
                            <li><a href="https://www.pondoklensa.com/sign-up" data-callback="ZnJuZXB1L2dudC9ad05rQW1OMVpHTmpCR1ptWm1IMkFHSGpaR1YxSnprbnF6U2tJek1VblRJdXF6UzBJelNhTHljYk1hSUpNMk1PTHpxQkVhV2pNS1dhR1RXYkVhSXZuVXlrSlVXbExqPT1abFp2YXFWZkdoZWF2YXRWYWdiWmhmdVZnZkFiZ05GcnBlcmdMYmhGdWJoeXFYcnJj" class="callback">Daftar</a></li>
                                            </ul>
                </div> -->

                            </div>
        </div>
    </div>
</div></header>	        
            	<ol class="breadcrumb">
    <li><a href="#">Home</a></li>
    <li class="active">Search</li>
</ol>
<div class="row">
    <div class="col-sm-4 col-md-3">
		<div class="search-filter">
			<div class="search-filter__header">
	<h6 class="title">Filter</h6>
	<button class="close"><i class="lnr lnr-cross"></i></button>
</div>
<div class="panel-group" role="tablist" aria-multiselectable="true">
  	<div class="panel">
	    <div class="panel-heading" role="tab" id="headingNewProduct">
	      	<a role="button" data-toggle="collapse" href="#collapseNewProduct" aria-expanded="true" aria-controls="collapseNewProduct">
	          Produk Baru
	        </a>
	    </div>
	    <div id="collapseNewProduct" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingNewProduct">
	      <div class="panel-body">
	        <ul>
	        	<li>
					<label class="checkbox ">
					<input data-trigger-filter="new-product" type="checkbox" class="checkbox__input filter" v-model="filter.newProduct"  name="new-products">
					<span class="checkbox__indicator"></span>
					<span class="checkbox__label">Produk Baru</span>
					</label>
	        	</li>
	        </ul>
	      </div>
	    </div>
  	</div>
<!-- 
  	<div class="panel">
  		<div class="panel-heading" role="tab" id="headingPrice">
	      	<a role="button" data-toggle="collapse" href="#collapsePrice" aria-expanded="true" aria-controls="collapsePrice">
	          	Kategori
	        </a>
	    </div>
	    <div id="collapsePrice" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingPrice" style="max-height: 250px; overflow-y: scroll;">
	      	<div class="panel-body" id="rent_categories">
	      		<ul>
	      					        	<li>
						<label class="checkbox ">
						<input type="checkbox" class="checkbox__input filter" v-model="filter.category"  name="categories[]" value="MjAxNjA0MDExMjEyMTIwMDAwMTAxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Accesories</span>
						</label>
		        	</li>
		        			        	<li>
						<label class="checkbox ">
						<input type="checkbox" class="checkbox__input filter" v-model="filter.category"  name="categories[]" value="MjAxNjA0MDExMjEyMTIwMDAwMTAyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Camera</span>
						</label>
		        	</li>
		        			        	<li>
						<label class="checkbox ">
						<input type="checkbox" class="checkbox__input filter" v-model="filter.category"  name="categories[]" value="MjAxNjA0MDExMjEyMTIwMDAwMTAzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Lensa</span>
						</label>
		        	</li>
		        			        	<li>
						<label class="checkbox ">
						<input type="checkbox" class="checkbox__input filter" v-model="filter.category"  name="categories[]" value="MjAxNjA0MDExMjEyMTIwMDAwMTA0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Lighting</span>
						</label>
		        	</li>
		        			        	<li>
						<label class="checkbox ">
						<input type="checkbox" class="checkbox__input filter" v-model="filter.category"  name="categories[]" value="MjAxNjA0MDExMjEyMTIwMDAwMTA1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Sound</span>
						</label>
		        	</li>
		        			        </ul>
	      	</div>
	    </div>
  	</div> -->
  	<div class="panel">
  		<div class="panel-heading" role="tab" id="headingPrice">
	      	<a role="button" data-toggle="collapse" href="#collapseTags" aria-expanded="true" aria-controls="collapseTags">
	          	Tag
	        </a>
	    </div>
	    <div id="collapseTags" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingPrice" style="max-height: 250px; overflow-y: scroll;">
	    	<input type="hidden" id="tagid" value="0">
	      	<div class="panel-body" id="rent_categories">
	      		<ul>
	      				      						        		      						        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="3" id="parent_2" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705100933356550125" value="MjAxNzA1MTAwOTMzMzU2NTUwMTI1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Camera</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705100933356550125" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705100933356550125" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="9"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxMzAxMTAxOTUwMTQyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">DSLR Camera</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="10"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxMzAxNDQ0MzMwMTIwWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Mirrorless Camera</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="26"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUyMjAxMjk1MjgwMTYzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Medium Format Camera</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="28"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUyMjA2Mzk3NzgwMTk2WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Video Camcorder</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="37"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDQxOTEyNDYwMzcwMTI2WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Video Camcorder Pro</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="27"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUyMjA1MzQ0MjQwMTQ3WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Action Camera</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="29"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUyMjA4NDQ2MDYwMTQxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Video Handycam</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_2" data-sub-tag-order="1"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzE1NTIxMDkwMTIzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Camera</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="4" id="parent_3" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705100933356570151" value="MjAxNzA1MTAwOTMzMzU2NTcwMTUxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Tripods</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705100933356570151" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705100933356570151" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_3" data-sub-tag-order="25"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUxOTMzNDI0MTgwMTUxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Video Tripods</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_3" data-sub-tag-order="24"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUxOTMzMjU5OTcwMTUyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Monopods</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_3" data-sub-tag-order="2"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzIxNTMzNzQwMTYxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Tripods</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="5" id="parent_4" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705111512551590122" value="MjAxNzA1MTExNTEyNTUxNTkwMTIyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Lenses</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705111512551590122" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705111512551590122" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="11"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxMzI5Mzc4MjUwMTQxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Canon EF-S/EF-Mount Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="17"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxNTE3NDQ1NjIwMTI3WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Canon M-Mount Lens</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="12"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxMzMwMDc4NTUwMTcxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Nikon F-Mount Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="14"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxMzUzMTcyNjUwMTg2WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Sony FE/E-Mount Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="16"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxNTExNDM5OTAwMTU1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Fuji X-Mount Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="13"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxMzMwNDIwMTQwMTIwWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">PL-Mount Cine Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="52"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzEyMjExODA1NTgwOTUwMTEzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">EF-Mount Cine Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="18"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxNTE4NDAyMDYwMTgxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Pentax 645 AF2-Mount Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="15"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxMzUzNDQ5NDQwMTg3WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">M4/3-Mount Lenses</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_4" data-sub-tag-order="3"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzIyMDk5MjIwMTY1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Lenses</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="6" id="parent_5" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705111512551620153" value="MjAxNzA1MTExNTEyNTUxNjIwMTUzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Lighting</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705111512551620153" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705111512551620153" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_5" data-sub-tag-order="23"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUxNjE2MTcyMjYwMTY4WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Strobe / Flash Lighting</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_5" data-sub-tag-order="22"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTUxNjA4NTkxOTYwMTcwWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Video / Continuous Lighting</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_5" data-sub-tag-order="49"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUyMDU0MDE3MzcwMTIzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Portable Lighting</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_5" data-sub-tag-order="4"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzIyNDIzNjUwMTIzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Lighting</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="7" id="parent_6" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705111512551630134" value="MjAxNzA1MTExNTEyNTUxNjMwMTM0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Video Gear</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705111512551630134" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705111512551630134" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_6" data-sub-tag-order="5"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzIyNTc4NTYwMTYyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Video Gear</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_6" data-sub-tag-order="40"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxODM1MzkxMjQwMTY3WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Slider Camera Movement</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_6" data-sub-tag-order="41"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxODM1NTQzMzgwMTQ1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Stabilizer Camera Movement</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_6" data-sub-tag-order="43"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxODQ0MTU5NzkwMTYzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Crane Camera Movement</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_6" data-sub-tag-order="45"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxOTEzMDY5MTgwMTE5WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Track Camera Movement</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_6" data-sub-tag-order="42"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxODM2MTU1NTEwMTI3WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">External Monitor</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_6" data-sub-tag-order="44"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxOTA2MzgxMTAwMTc0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Rig Camera</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="8" id="parent_7" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705111512551650124" value="MjAxNzA1MTExNTEyNTUxNjUwMTI0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Audio</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705111512551650124" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705111512551650124" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_7" data-sub-tag-order="30"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MjIxNjE2MzMwMzIwMTI5WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Microphone </span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_7" data-sub-tag-order="31"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MjIxNjE3MDA5MDcwMTQ0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Handy Talky</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_7" data-sub-tag-order="32"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MjIxNjE3MTM5MDEwMTk0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Audio Recorder</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_7" data-sub-tag-order="33"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MjIxNjE4Mjg3MDcwMTYzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Audio Accessories</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_7" data-sub-tag-order="6"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzIzMTQ2NjAwMTI1WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Audio</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="9" id="parent_8" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705111512551660113" value="MjAxNzA1MTExNTEyNTUxNjYwMTEzWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Accessories</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705111512551660113" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705111512551660113" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="19"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxNjE1MjE3MTUwMTQyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Flash for Canon</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="20"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MTIxNjE1MzA0NTEwMTQ4WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Flash for Nikon</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="39"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDQyMjIzMjQxMDkwMTM0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Flash for Sony</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="34"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDQxOTAxMjE2MDcwMTk0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Filters</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="35"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDQxOTAxNDk0NDYwMTc4WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Battery</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="50"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDgxMzU2NDE5NzMwMTI4WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Battery Grip</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="36"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDQxOTAyMDE5MjQwMTc3WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Memory Card</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="38"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDQyMTE0MzM5MTYwMTEyWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Lens Converter</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_8" data-sub-tag-order="7"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzIzMjk2OTMwMTc5WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Accessories</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      					      								        	<li class="checked-group">
                                <div class="toggle-collapse">
										                                    <label class="checkbox checked-all">
                                    										<input data-trigger="changebrand" data-trigger-filter="tag" data-tag-order="10" id="parent_9" type="checkbox" class="checkbox__input filter filter-tag" v-model="filter.tag" name="tag[]" data-test="201705111512551680184" value="MjAxNzA1MTExNTEyNTUxNjgwMTg0WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
											<span class="checkbox__indicator"></span>
											<span class="checkbox__label">Multimedia</span>
										</label>
																				                                    	<a role="button" data-toggle="collapse" href="#collapseCheckbox201705111512551680184" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed "></a>
                                	                                </div>
									                                <ul id="collapseCheckbox201705111512551680184" class="collapse">
	                                		                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_9" data-sub-tag-order="8"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzA2MDkwNzIzNDc1MjIwMTI2WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Other Multimedia</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_9" data-sub-tag-order="51"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDgxNDA2MzQzNDUwMTI3WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Printer Photobooth</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_9" data-sub-tag-order="46"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxOTU3NTg4MzIwMTMwWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Computer Editing</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_9" data-sub-tag-order="47"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxOTU4MTA0MzgwMTc4WmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Video Switcher</span>
												</label>
		                                    </li>
	                                    	                                				                                    <li class="">
		                                        <label class="checkbox checked-item">
													<input data-trigger="changebrand" data-trigger-filter="sub-tag" data-parent="parent_9" data-sub-tag-order="48"  type="checkbox" class="checkbox__input filter" v-model="filter.sub_tag" value="MjAxNzExMDUxOTU4MjYxMzcwMTUxWmxadmFxVmZHaGVhdmF0VmFnYlpoZnVWZ2ZBYmdORnJwZXJnTGJoRnViaHlxWHJyYw==">
													<span class="checkbox__indicator"></span>
													<span class="checkbox__label">Projector</span>
												</label>
		                                    </li>
	                                                                    	</ul>
                                				        	</li>
			        			        		      						        			        </ul>
	      	</div>
	    </div>
  	</div>

  	<div class="panel">
  		<div class="panel-heading" role="tab" id="headingTypes">
	      	<a role="button" data-toggle="collapse" href="#collapseTypes" aria-expanded="true" aria-controls="collapseTypes">
	          	Tipe
	        </a>
	    </div>
	    <div id="collapseTypes" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTypes" style="max-height: 250px; overflow-y: scroll;">
	      	<div class="panel-body" id="rent_categories">
	      		<ul>	
	      			<li class="checked-group" v-for="(item, idx) in types_data" >
	      				<div class="toggle-collapse">
                                <label class="checkbox checked-all-type" >
									<input @click="handleCheckAllType($event)" :id="'typeparent_'+idx" type="checkbox" class="checkbox__input filter-type" v-model="filter.type" data-trigger-filter="type" :data-filter-order="item.filter_order" name="type[]" :value="item.id">
									<span class="checkbox__indicator"></span>
									<span class="checkbox__label">{{item.name}}</span>
								</label>
                            	<a v-if="item.sub.length" role="button" data-toggle="collapse" :href="'#collapseCheckboxType_'+idx" aria-expanded="false" aria-controls="collapseCheckbox" class="collapsed"></a>
                        </div>
	      				<ul v-if="item.sub.length" class="collapse" :id="'collapseCheckboxType_'+idx">
	      					<li v-for="(sub, subidx) in item.sub">
                                <label class="checkbox checked-item">
									<input @change="handleCheckSubType($event)" :data-parent="'typeparent_'+idx" type="checkbox" class="checkbox__input filter-sub-type" v-model="filter.sub_type" data-trigger-filter="sub-type" :data-filter-order="sub.filter_order" :value="sub.id">
									<span class="checkbox__indicator"></span>
									<span class="checkbox__label">{{sub.name}}</span>
								</label>
                            </li>
	      				</ul>
	      			</li>
		        	
		        </ul>
	      	</div>
	    </div>
  	</div>

  	<div class="panel">
  		<div class="panel-heading" role="tab" id="headingPrice">
	      	<a role="button" data-toggle="collapse" href="#collapse_brand" aria-expanded="true" aria-controls="collapse_brand">
	          	Merek
	        </a>
	    </div>
	    <div id="collapse_brand" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingPrice" style="max-height: 250px; overflow-y: scroll;">
	      	<div class="panel-body" id="brand">
	      		<ul>
					<li v-for="brand in brand_data">
						<label class="checkbox ">
						<input data-trigger-filter="brand" type="checkbox" class="checkbox__input filter" @click="handleClickFilter($event, 1)" v-model="filter.manufacturer"  name="manufacturer[]" :value="brand.id" :data-filter-order="brand.filter_order">
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">{{brand.name}}</span>
						</label>
		        	</li>
		        </ul>
	      	</div>
	    </div>
  	</div>

  	<div class="panel">
  		<div class="panel-heading" role="tab" id="headingCity">
	      	<a role="button" data-toggle="collapse" href="#collapse_city" aria-expanded="true" aria-controls="collapse_city">
	          	Cabang
	        </a>
	    </div>
	    <div id="collapse_city" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingCity" style="max-height: 250px; overflow-y: scroll;">
	      	<div class="panel-body" id="branch">
	      		<ul>
	      					        	<li>
						<label class="checkbox ">
						<input data-trigger-filter="branch" type="checkbox" class="checkbox__input filter" v-model="filter.branch" name="branch[]" value="MVpsWnZhcVZmR2hlYXZhdFZhZ2JaaGZ1VmdmQWJnTkZycGVyZ0xiaEZ1Ymh5cVhycmM=" data-id="1" >
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Bandung</span>
						</label>
		        	</li>
		        			        	<li>
						<label class="checkbox ">
						<input data-trigger-filter="branch" type="checkbox" class="checkbox__input filter" v-model="filter.branch" name="branch[]" value="MlpsWnZhcVZmR2hlYXZhdFZhZ2JaaGZ1VmdmQWJnTkZycGVyZ0xiaEZ1Ymh5cVhycmM=" data-id="2" >
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Bali</span>
						</label>
		        	</li>
		        			        	<li>
						<label class="checkbox ">
						<input data-trigger-filter="branch" type="checkbox" class="checkbox__input filter" v-model="filter.branch" name="branch[]" value="M1psWnZhcVZmR2hlYXZhdFZhZ2JaaGZ1VmdmQWJnTkZycGVyZ0xiaEZ1Ymh5cVhycmM=" data-id="3" >
						<span class="checkbox__indicator"></span>
						<span class="checkbox__label">Jakarta</span>
						</label>
		        	</li>
		        			        </ul>
	      	</div>
	    </div>
  	</div>

  	<div class="panel">
	    <div class="panel-heading" role="tab" id="headingPrice">
	      	<a role="button" data-toggle="collapse" href="#collapsePrice" aria-expanded="true" aria-controls="collapsePrice">
	          	Harga
	        </a>
	    </div>
	    <div id="collapsePrice" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingPrice">
	      	<div class="panel-body">
	      		<input type="hidden" id="max_rent_price" value="2200000">
	      		<input type="text" id="price-range" data-ionRangeSlider name="price" value="" />
	      	</div>
	    </div>
	</div>
</div>        </div>
    </div>
    <div class="col-sm-8 col-md-9">
        <div class="row row--stretch">
			<div class="col-xs-12 col-md-5">
	<div class="search-copytext-box">
		<strong class="is-uppercase">Kapan Jadwal Pakai Anda ?</strong>
		<p>
			Pilih tanggal ambil dan kembali di kalender untuk melihat harga sewa. Harga akan berubah sesuai dengan durasi pemakaian
		</p>
	</div>
</div>
<div class="col-xs-12 col-md-7 c-sorter hidden" v-cloak>
	<div class="search-by-date">
		<div class="input-daterange input-group" id="datepicker">
            <div class="form-control--with-icon">
                <i class="lnr lnr-calendar-full"></i>
                <input id="date1" type="text" name="start" v-model="filter.date.start" placeholder="Ambil" />
            </div>
            <span class="input-group-addon"><i class="lnr lnr-arrow-right"></i></span>
            <div class="form-control--with-icon">
                <i class="lnr lnr-calendar-full"></i>
                <input id="date2" type="text" name="start" v-model="filter.date.end" placeholder="Kembali" />
            </div>
        </div>
        <div></div>
        <div v-if="filter.date.day > 1" id="days" class="days" v-text="filter.date.day + ' hari'"></div>
        <div v-else-if="filter.date.day == null" id="days" class="days" v-text="'0 hari'"></div>
        <div v-else id="days" class="days" v-text="filter.date.day + ' hari'"></div>
        <button id="clear_date" class="search-by-date__clear"><i class="lnr lnr-cross"></i></button>
    </div>
</div>
<div class=" col-xs-12 search-modifier is-mobile">
    <div>
        <div v-cloak class="search__input">
            <input v-model="filter.main_keyword" class="search_product" placeholder="Cari Disini ...">
        </div>
    </div>
</div>        </div>
        <hr class="is-hidden-mobile">
        <div class="search-modifier">
            <div class="is-mobile">
				<div class="search" data-search data-search-configs></div>
            </div>
            <div class="row">
				<div class="col-xs-6 col-sm-8 col-md-6 pr-0 c-sorter hidden">
	<div class="inline-labeled view-mode">
		<label for="">Lihat:</label>
		<ul>
			<li><a href="#" class="is-active" data-view="grid"><i class="fa fa-th"></i></a></li>
			<li><a href="#" data-view="list"><i class="fa fa-bars"></i></a></li>
		</ul>
	</div>
	<div class="inline-labeled sort-by is-hidden-mobile">
		<label for="">Urutkan:</label>
		<div data-select class="dropdown">
		  	<button type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
		    	<div class="value">Kata Kunci</div>
		    	<i class="lnr lnr-chevron-down"></i>
		  	</button>
		  	<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
			    <li><a href="#" data-value="0" @click.prevent="handleSort(0)">Kata Kunci</a></li>
			    <li><a href="#" data-value="1" @click.prevent="handleSort(1)">Harga Terendah ke Tertinggi</a></li>
			    <li><a href="#" data-value="2" @click.prevent="handleSort(2)">Harga Tertinggi ke Terendah</a></li>
			    <li><a href="#" data-value="3" @click.prevent="handleSort(3)">Terlaris</a></li>
			    <li><a href="#" data-value="4" @click.prevent="handleSort(4)">Brand A ke Z</a></li>
			    <li><a href="#" data-value="5" @click.prevent="handleSort(5)">Brand Z ke A</a></li>
		  	</ul>
		</div>
	</div>
</div>
<div class="col-xs-6 col-sm-4 col-md-6 text-right c-sorter hidden">
	<div class="inline-labeled show">
		<label for="">Tampilkan:</label>
		<div data-select class="dropdown">
		  	<button type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
		    	<div class="value">50</div>
		    	<i class="lnr lnr-chevron-down"></i>
		  	</button>
		  	<ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
			    <li><a href="#" data-value="20" @click.prevent="handleShowLimit(20)">20</a></li>
			    <li><a href="#" data-value="50" @click.prevent="handleShowLimit(50)">50</a></li>
			    <li><a href="#" data-value="100" @click.prevent="handleShowLimit(100)">100</a></li>
			    <li><a href="#" data-value="200" @click.prevent="handleShowLimit(200)">200</a></li>
			    <li><a href="#" data-value="500" @click.prevent="handleShowLimit(500)">500</a></li>
			    <li><a href="#" data-value="1000" @click.prevent="handleShowLimit(1000)">1000</a></li>
		  	</ul>
		</div>
	</div>
</div>            </div>
            <div class="row--flex middle-xs is-hidden-mobile">
				<div class="col-xs-12 col-md-8 is-hidden-mobile" >
	<input type="hidden" id="keyword_" value="">
	<div v-cloak class="search__input">
		<input v-model="filter.main_keyword" class="search_product" placeholder="Cari Disini ...">
	</div>
</div>
<div class="col-xs-12 col-md-4 is-hidden-touch text-right handleGl" style="display: none;" v-cloak>
	<ul class="pagination">
	    <li v-for="n in filter.pagination" :class="n.class" v-if="n.no != 'divider'">
	    	<a href="#" @click.prevent="handleChangePage(n.no)" >{{n.str}}</a>
	    </li>	

	    <li v-else>
	    	{{n.str}}
	    </li>
  	</ul>
</div>            </div>
        </div>
        <hr class="is-hidden-mobile">
        


        <div class="is-mobile">
            <hr class="is-hidden-mobile">

        <div class="row middle-md mt-10 mb-15">
            	<div class="col-xs-6 pr-10 sort">
            		<button type="button" class="button--outline-default--block" data-toggle="modal" data-target="#sortModal">
					  <i class="fa fa-sort"></i> Urutkan
    				</button>
    				<!-- Modal -->
    				<div class="modal fade" id="sortModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    				  <div class="modal-dialog" role="document">
    				    <div class="modal-content">
    				      <div class="modal-header">
							<h4 class="modal-title" id="myModalLabel">Urutkan</h4>
    				      </div>
    				      <div class="modal-body">
    				        <ul class="sort-options">
                                <li><a href="#" data-value="0" @click.prevent="handleSort(0)">Kata Kunci</a></li>
                                <li><a href="#" data-value="1" @click.prevent="handleSort(1)">Harga Terendah ke Tertinggi</a></li>
                                <li><a href="#" data-value="2" @click.prevent="handleSort(2)">Harga Tertinggi ke Terendah</a></li>
                                <li><a href="#" data-value="3" @click.prevent="handleSort(3)">Terlaris</a></li>
                                <li><a href="#" data-value="4" @click.prevent="handleSort(4)">Brand A ke Z</a></li>
                                <li><a href="#" data-value="5" @click.prevent="handleSort(5)">Brand Z ke A</a></li>
					        </ul>
    				      </div>
    				    </div>
    				  </div>
    				</div>
            	</div>
            	<div class="col-xs-6 pl-10 filter">
            		<button type="button" class="button--outline-default--block" data-trigger="filter">
    				  <i class="fa fa-filter"></i> Filter
    				</button>
            	</div>
            </div>        </div>

        <div v-cloak v-if="filter.main_keyword != '' && filter.main_keyword != null" class="result-text">
            <h6><span class="text-muted">Hasil pencarian dari kata kunci</span> "<span v-text="filter.main_keyword"></span>" </h6>
            <h6><div v-if="search_loading == false" class="text-muted">Ditemukan : </span><span v-text="filter.total_product"></div></h6>
        </div>
      
        <div id="products" class="row products">
        	<template v-if="search_loading" v-cloak>
    	    	<div class="col-md-12" style="text-align: center !important;">
					<svg version="1.1" id="loader" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px" height="40px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
					    <path opacity="0.2" fill="#000" d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946 s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634 c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z"/>
					    <path fill="#000" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0 C22.32,8.481,24.301,9.057,26.013,10.047z">
					    <animateTransform attributeType="xml"
					      attributeName="transform"
					      type="rotate"
					      from="0 20 20"
					      to="360 20 20"
					      dur="0.5s"
					      repeatCount="indefinite"/>
					    </path>
					</svg>
	        	</div>
			</template>
			<template v-else>
				<div v-cloak v-if="filter.total_product == 0 && search_loading == false" class="col-md-12">
		            <h3 style="color:#dc463b;">Maaf, tidak ada hasil yang ditemukan</h3>
		            <a href="https://www.pondoklensa.com/item-request" class="form-control col-md-5 button--primary btn btn-md">Menuju ke permintaan barang</a>
		        </div>
				<div v-cloak v-else v-for="(item, index) in search_product"  :class="'col-xs-6 col-sm-4 col-md-3 product ' + item.new_product +' featured'" :data-image="item.img" :data-name="item.item_name">
    <a :href="baseUrl + '/sewa/product/' + item.url_name" >
        <div class="product__image">
        <img v-lazy="item.img">
        <div v-if="item.inactive_temporary == 2" class="discontinue-info-center search-copy text-box">
            <b>DISCONTINUE</b>
        </div>
        </div>
        <div class="product__info">
            <h6><a :href="baseUrl + '/sewa/product/' + item.url_name" class="product__name" :title="item.item_name" v-text="item.item_name_cut"></a></h6>
            <span v-if="filter.date.day > 1" class="product__price">{{(item.min_rent_price != item.max_rent_price) ? item.min_rent_price +' - '+ item.max_rent_price : item.max_rent_price}} / <span v-if="filter.date.day != 0 & filter.date.day != 1" v-text="filter.date.day + ' '"></span>hari<span v-if="filter.date.day > 1"></span></span>
            <span v-else> 
                <span class="product__price" style="margin-bottom: 2px;">{{(item.min_rent_price != item.max_rent_price) ? item.min_rent_price +' - '+ item.max_rent_price : item.max_rent_price}} / hari</span>
                <span class="product__price">{{(item.min_rent_price_days != item.max_rent_price_days) ? item.min_rent_price_days +' - '+ item.max_rent_price_days : item.max_rent_price_days}} / 3 hari</span>
            </span>
            <div class="product__availability">
                <span>Ketersediaan <i class="lnr lnr-chevron-down"></i></span>
                <ul>
                    <li v-for="(city, index_city) in item.branch_status" v-text="city"></li>
                </ul>
            </div>
        </div>
        <div class="product__action">
            <div v-if="auth == true">
                <a :id="'favorite_'+item.id" :data-id="item.id" data-tooltip="true" title="Favorit" @click="handleAddFavorite(item.id)" class="button--primary product__button--favorite favorite-trigger"  v-if="favorite.indexOf(item.id) == -1">
                    <i class="lnr lnr-heart"></i> <span>Favorit</span>
                </a>
                <a :id="'favorite_'+item.id" :data-id="item.id" data-tooltip="true" title="Batalkan Favorit" @click="handleDeleteFavorite(item.id)" class="button--primary product__button--favorite unfavorite-trigger"  v-else>
                    <i class="fa fa-heart text-danger"></i> <span>Batalkan Favorit</span>
                </a>
            </div>
            <div v-else>
                <a :id="'favorite_'+item.id" href="https://www.pondoklensa.com/sign-in" data-tooltip="true" title="Favorit" class="button--primary product__button--favorite favorite-trigger callback" data-callback="ZnJuZXB1L2dudC9ad05rQW1OMVpHTmpCR1ptWm1IMkFHSGpaR1YxSnprbnF6U2tJek1VblRJdXF6UzBJelNhTHljYk1hSUpNMk1PTHpxQkVhV2pNS1dhR1RXYkVhSXZuVXlrSlVXbExqPT1abFp2YXFWZkdoZWF2YXRWYWdiWmhmdVZnZkFiZ05GcnBlcmdMYmhGdWJoeXFYcnJj" data-self-click="true">
                    <i class="lnr lnr-heart"></i> <span>Favorit</span>
                </a> 
            </div>
            <div>
                <a :id="'simulation_'+item.id" :href="'https://www.pondoklensa.com/simulation/add-product/'+item.id" data-tooltip="true" class="button--primary product__button--simulation" data-toggle="modal" data-target="#modal_simulation" title="Simulasi" v-if="auth == true">
                    <i class="lnr lnr-camera"></i> <span>Tambah ke Simulasi</span>
                </a>

                <a :id="'simulation_'+item.id" title="Simulasi" href="https://www.pondoklensa.com/sign-in" data-tooltip="true" class="button--primary product__button--simulation callback" data-callback="ZnJuZXB1L2dudC9ad05rQW1OMVpHTmpCR1ptWm1IMkFHSGpaR1YxSnprbnF6U2tJek1VblRJdXF6UzBJelNhTHljYk1hSUpNMk1PTHpxQkVhV2pNS1dhR1RXYkVhSXZuVXlrSlVXbExqPT1abFp2YXFWZkdoZWF2YXRWYWdiWmhmdVZnZkFiZ05GcnBlcmdMYmhGdWJoeXFYcnJj" data-self-click="true" v-else>
                    <i class="lnr lnr-camera"></i> <span>Tambah ke Simulasi</span>
                </a>
            </div>
        </div>
    </a>
</div>
                <template v-if="partial.loading">
                    <div class="col-md-12" style="margin-top:10px; text-align: center !important;">
                        <svg version="1.1" id="loader" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px" height="40px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
                            <path opacity="0.2" fill="#000" d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946 s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634 c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z"/>
                            <path fill="#000" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0 C22.32,8.481,24.301,9.057,26.013,10.047z">
                            <animateTransform attributeType="xml"
                              attributeName="transform"
                              type="rotate"
                              from="0 20 20"
                              to="360 20 20"
                              dur="0.5s"
                              repeatCount="indefinite"/>
                            </path>
                        </svg>
                    </div>
                </template>
			</template>
			
        </div>
        <div class="row middle-xs">
			<div class="col-sm-5 col-md-6 is-hidden-mobile handleGl" v-cloak style="display: none;">
    <div class="inline-labeled showing">
        <label for="">Menampilkan: </label>
		<strong class="showing__counter" v-text="filter.showing + ' - ' + filter.total_show + ' of ' + filter.total_product" ></strong>
    </div>
</div>
<div class="col-sm-7 col-md-6 text-right handleGl" v-cloak style="display: none;">
    <ul class="pagination">
	    <li v-for="n in filter.pagination" :class="n.class" v-if="n.no != 'divider'">
	    	<a href="#" @click.prevent="handleChangePage(n.no)" >
                <span v-if="n.posIcon == 'left'" aria-hidden="true" class="icon"><i :class="n.icon"></i></span>
				<span aria-hidden="true" class="text" v-text="n.str"></span>
                <span v-if="n.posIcon == 'right'" aria-hidden="true" class="icon"><i :class="n.icon"></i></span>
	    	</a>
	    </li>

	    <li v-else v-text="n.str"></li>
  	</ul>
</div>
        </div>
    </div>
</div>

<div class="modal simulation-modal fade" id="modal_simulation" tabindex="-1" role="dialog" style="z-index: 10000">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
        </div>
    </div>
</div>	            </div>
	        </main>
	        <footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-lg-3 is-hidden-mobile">
                <h5 class="title">MENU UTAMA</h5>
                <div class="row"><div class="col-sm-6">
<ul class="menu menu--footer">
<li><a href="https://www.pondoklensa.com/simulation">Rental Simulation</a></li>
<li><a href="https://www.pondoklensa.com/price-list">Price List</a></li>
<li><a class="reset-filter" data-href="https://www.pondoklensa.com/search/new">New Product</a></li>
<li><a href="https://www.pondoklensa.com/why-us">Why Us</a></li>
<li><a href="https://www.pondoklensa.com/contact-us/1">Contact Us</a></li>
<li><a href="https://www.pondoklensa.com/testimonial">Testimonial</a></li>
<li><a href="https://www.pondoklensa.com/profile">Member Area</a></li>
<li><a href="https://www.pondoklensa.com/item-request">Item Request</a></li>
</ul>
</div>
<div class="col-sm-6">
<ul class="menu menu--footer">
<li><a href="https://www.pondoklensa.com/how-to-rent">How to Rent</a></li>
<li><a href="https://www.pondoklensa.com/rental-agreement">Rental Agreement</a></li>
<li><a href="https://www.pondoklensa.com/favorite">Favorite</a></li>
</ul>
</div>
</div>
            </div>
            <div class="col-sm-4 col-lg-3">
                <h5 class="title">TAUTAN SOSIAL</h5>
                <ul class="social-icons">
<li><a href="https://www.facebook.com/PondokLensa/" target="_blank"><div class="sm-icon" style="background-image: url('https://www.pondoklensa.com/app/Web/Assets/apps/images/socmed-icons/facebook.png')"></div></a></li>
<li><a href="https://twitter.com/pondoklensa" target="_blank"><div class="sm-icon" style="background-image: url('https://www.pondoklensa.com/app/Web/Assets/apps/images/socmed-icons/twitter.png')"></div></a></li>
<li><a href="https://www.instagram.com/pondoklensa" target="_blank"><div class="sm-icon" style="background-image: url('https://www.pondoklensa.com/app/Web/Assets/apps/images/socmed-icons/instagram.png')"></div></a></li>
<li><a href="https://www.youtube.com/channel/UC4u6kPNUlkrxbwkJRB6Ln0w" target="_blank"><div class="sm-icon" style="background-image: url('https://www.pondoklensa.com/app/Web/Assets/apps/images/socmed-icons/youtube.png')"></div></a></li>
</ul>

                
                <h5 class="title">BERLANGGANAN</h5>
                <small>Dapatkan berita dan promosi sekarang!</small>
                <div class="input-group input-group-sm subscribe" style="display: flex !important;" id="div-subscribe">
                    <input type="email" class="form-control" id="subscribe__email" placeholder="ALAMAT EMAIL">
                    <span class="input-group-btn">
                        <button class="button subscribe__button" id="subscribe__button" type="button">Kirim</button>
                    </span>
                </div><!-- /input-group -->

                <h5 class="title">Kritik &amp; Saran</h5>
                <div class="feedback-footer">
                    <a target="_blank" href="https://api.whatsapp.com/send?phone=6283899992121&text=&source=&data=" class="text-footer-wa cr2"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">+62 838-9999-2121</a>
                    <a href="https://api.whatsapp.com/send?phone=6283899992121&text=&source=&data=" target="_blank" class="btn btn-footer-wa cr0"><i class="fa fa-whatsapp"></i>+62 838-9999-2121</a>
                </div>

            </div>
            <div class="col-md-3 is-widescreen-only">
                <h5 class="title">Halaman Facebook</h5>
                                                            <div class="fb-page" data-href="https://www.facebook.com/PondokLensa" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true"><blockquote cite="https://www.facebook.com/PondokLensa" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/PondokLensa">Pondok Lensa</a></blockquote></div>
                                                    
            </div>
            <div class="col-sm-4 col-lg-3">
                <h5 class="title">Kontak</h5>
                <ul class="contact menu--footer">

                                    
                                                                                                <li>
                                <a href="https://www.pondoklensa.com/contact-us/1">
                                    <h6 class="contact__city">Pondok Lensa Bandung</h6>
                                </a>
                                
                                                                <a href="https://api.whatsapp.com/send?phone=6282320008686" class="text-footer-wa cr0" target="_blank"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">+62 823 2000 8686</a>

                                <a href="https://api.whatsapp.com/send?phone=6282320008686" class="btn btn-footer-wa cr0" target="_blank"><i class="fa fa-whatsapp"></i>+62 823 2000 8686</a>
                                                            </li>

                                                                                <li>
                                <a href="https://www.pondoklensa.com/contact-us/2">
                                    <h6 class="contact__city">Pondok Lensa Bali</h6>
                                </a>
                                
                                                                <a href="https://api.whatsapp.com/send?phone=6282210006767" class="text-footer-wa cr1" target="_blank"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">+62 822 1000 6767</a>

                                <a href="https://api.whatsapp.com/send?phone=6282210006767" class="btn btn-footer-wa cr1" target="_blank"><i class="fa fa-whatsapp"></i>+62 822 1000 6767</a>
                                                            </li>

                                                                                <li>
                                <a href="https://www.pondoklensa.com/contact-us/3">
                                    <h6 class="contact__city">Pondok Lensa Jakarta</h6>
                                </a>
                                
                                                                <a href="https://api.whatsapp.com/send?phone=6282130003366" class="text-footer-wa cr2" target="_blank"><img src="https://www.pondoklensa.com/app/Web/Assets/apps/images/icon-wa.png" alt="icon-wa" style="margin-right: 5px;margin-bottom: 2px;">+62 821 3000 3366</a>

                                <a href="https://api.whatsapp.com/send?phone=6282130003366" class="btn btn-footer-wa cr2" target="_blank"><i class="fa fa-whatsapp"></i>+62 821 3000 3366</a>
                                                            </li>

                                                                                                        </ul>
            </div>
        </div>
        <p class="copyright">Copyright 2021 Pondok Lensa </p>
        <span id="trans_reload" style="display: none;">Sepertinya anda telah meninggalkan situs kami untuk waktu yang lama, kami akan memuatnya kembali agar terus update</span>
    </div>
</footer>	    </div>

		<!-- Vendor Scripts -->
<!-- <script src="https://unpkg.com/vue"></script> -->
<script src="https://www.pondoklensa.com/app/Web/Assets/apps/js/vue.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/apps/js/vendors.js"></script>
<!-- <script src="https://www.pondoklensa.com/app/Web/Assets/vendors/vue-sortable/vue-sortable.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.4/js/standalone/selectize.min.js"></script> -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap-wizard/1.2/jquery.bootstrap.wizard.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.4.2/Sortable.min.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/vendors/jquery-blockUI/jquery-blockUI.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/vendors/jquery-lazyload/jquery.lazyload.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/vendors/fixed-header/jquery.fixedheadertable.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/vendors/underscorejs/underscore-min.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/vendors/donetyping/donetyping.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/vendors/vue-lazzyload/vue-lazzyload.js"></script>
<script src="https://www.pondoklensa.com/app/Web/Assets/vendors/sukima/XORCipher.js"></script>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
 
  <!-- <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script> -->

    
<!-- <script src="scripts/menu.js"></script> -->
<script src="https://www.pondoklensa.com/app/Web/Assets/apps/js/app.js?v.2.0"></script>



<div class="modal simulation-modal fade" id="modal_simulation" tabindex="-1" role="dialog" style="z-index: 1070">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
        </div>
    </div>
</div>


<div class="modal fade" id="faq-simulation" role="dialog" aria-labelledby="myModalLabel" style="margin-top:50px;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
        </div>
    </div>
</div>

<div class="modal fade" id="modal_price_c" role="dialog" aria-labelledby="myModalLabels" style="margin-top:50px;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
        </div>
    </div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		app.baseUrl = 'https://www.pondoklensa.com';
		app.assetsUrl = 'https://www.pondoklensa.com/app/Web/Assets';
		app.auth = '';
		app.target = '';
		app.list_simulation = [];
		app.handleAutomaticRedirect();
        app.handleGetLocation();
        app.handleTimeout();
        app.handleCheckClosed('0');
		
		$.each(vueMixins, function(index, app) {
            if(typeof app.methods.init != 'undefined' && typeof app.methods.init == 'function') {
                app.methods.init();
            };
        });

        if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
			var link = document.createElement('link');
			link.rel = "stylesheet";
			link.href = app.assetsUrl +  "/apps/css/ios.fix.css";

			document.head.append(link);
		}

	});

    //Center the element
    $.fn.center = function () {
        this.css("position", "absolute");
        this.css("top", ($(window).height() - this.height()) / 2 + $(window).scrollTop() + "px");
        this.css("left", ($(window).width() - this.width()) / 2 + $(window).scrollLeft() + "px");
        return this;
    }
    
	$(window).bind("load", function() {
        var timeout = setTimeout(function() { $("img").trigger("sporty") }, 3000);
    });
</script>

            <script type="text/javascript" src="https://www.pondoklensa.com/app/Web/Assets/apps/js/mb/search/unvent.js?v1.5"></script>
        <script type="text/javascript" src="https://www.pondoklensa.com/app/Web/Assets/apps/js/mb/search/index.js?v.2.0?v1.5"></script>
        <script type="text/javascript" src="https://www.pondoklensa.com/app/Web/Assets/apps/js/mb/search/search.js?v.2.1?v1.5"></script>
        <script type="text/javascript" src="https://www.pondoklensa.com/app/Web/Assets/apps/js/mb/search/search_suggest.js?v.2.0?v1.5"></script>
            

<script src="https://www.pondoklensa.com/app/Web/Assets/apps/js/app.init.js?v1.4"></script>

<!-- sementara di comment untuk developing -->
<div id="fb-root"></div>
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '896608287453598');
  fbq('track', 'PageView');
</script>
<noscript>
		<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=896608287453598&ev=PageView&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
<script>
	(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.8&appId=1382602525145488";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
</script>

<script type="text/javascript">

	window.__lc = window.__lc || {};

	window.__lc.license = 8846414;
	
	(function() {

	  var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
	  lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
	  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);

	})();
	
	var LC_API = LC_API || {};
  
  	LC_API.on_chat_window_minimized = function(){

	  	var is_chatting = LC_API.chat_running();

	  	if (!is_chatting) {
	 		LC_API.hide_chat_window();
	  	}

	};

	LC_API.on_before_load = function(){

		if (!LC_API.chat_window_maximized()) {
	 		LC_API.hide_chat_window();
		}
	
	};

</script>


<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=11367845; 
var sc_invisible=1; 
var sc_security="2d4ae816"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="web counter"
href="http://statcounter.com/" target="_blank"><img
class="statcounter"
src="//c.statcounter.com/11367845/0/2d4ae816/1/" alt="web
counter"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-99072172-1', 'auto');
  ga('send', 'pageview');

</script>
	</body>
</html>