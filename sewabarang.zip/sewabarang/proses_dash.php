<?php
include "koneksi.php";
$db = new database();

$aksi = $_GET['aksi'];
	if ($aksi == "data"){
		$db->data ($_POST ['idpelanggan']);
			header ("location:data.php");
	}
?>