<!DOCTYPE html>
<html lang="en">

	<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

<div class="col-sm-8 col-md-9">
        <div class="row row--stretch">
			<div class="col-xs-12 col-md-5">
	<div class="search-copytext-box">
		<strong class="is-uppercase">Kapan Jadwal Pakai Anda ?</strong>
		<p>
			Pilih tanggal ambil dan kembali di kalender untuk melihat harga sewa. Harga akan berubah sesuai dengan durasi pemakaian
		</p>
	</div>
</div>
<div class="col-xs-12 col-md-7 c-sorter hidden" v-cloak>
	<div class="search-by-date">
		<div class="input-daterange input-group" id="datepicker">
            <div class="form-control--with-icon">
                <i class="lnr lnr-calendar-full"></i>
                <input id="date1" type="text" name="start" v-model="filter.date.start" placeholder="Ambil" />
            </div>
            <span class="input-group-addon"><i class="lnr lnr-arrow-right"></i></span>
            <div class="form-control--with-icon">
                <i class="lnr lnr-calendar-full"></i>
                <input id="date2" type="text" name="start" v-model="filter.date.end" placeholder="Kembali" />
            </div>
        </div>
        <div></div>
        <div v-if="filter.date.day > 1" id="days" class="days" v-text="filter.date.day + ' hari'"></div>
        <div v-else-if="filter.date.day == null" id="days" class="days" v-text="'0 hari'"></div>
        <div v-else id="days" class="days" v-text="filter.date.day + ' hari'"></div>
        <button id="clear_date" class="search-by-date__clear"><i class="lnr lnr-cross"></i></button>
    </div>
</div>
</head>
</html>