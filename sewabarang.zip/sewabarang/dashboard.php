<script type="text/javascript">
	function hapus_sewa(kode_sewa){
		var kodesewanya = kode_sewa;
		
		var tanya = confirm("Apakah Yakin Ingin Menghapus Data ?");
		if (!tanya) {
		  
		}else{
		  // proceed with form submission
		  $.ajax({
			url: 'proses.php?aksi=hapus_sewa_langsung',
			type: 'POST',
			data: {
				'kode_sewa' : kodesewanya,
			},
			success: function(hasil){
				alert('berhasil dihapus');
				$('#sewa_'+kode_sewa).remove();
			}
		  });
		 }
		};
</script>
<html>
<head><title>Data Persewaan</title>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">    
    <a class="navbar-brand" href="#">Persewaan Barang</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mr-auto">
              <li class="nav-item">
          <a class="nav-link" href="dashboard.php">Dashboard</a>
        </li>
                <li class="nav-item">
          <a class="nav-link" href="datasewa.php">Data Persewaan</a>
        </li>
              </ul>
      <a href="?q=logout" onclick='return confirm("Apakah Yakin Ingin Logout?")' class="btn btn-danger">Keluar</a>
    </div>
   </div>
  </nav>   <div class="container-fluid" style="margin-top:2%">
	<div class="card mx-auto">
     <div class="card-header">
	 	<div class="row">
		   <div class="col-xs-6 col-sm-6">
	   		<h2>Dashboard</h2>
			   Persewaan Barang<h6></h6>		   </div>
		   <!-- awal -->
			 
				<div class="col-xs-6 col-sm-6">
				<div class="input-group">
					<input type="text" class="form-control" placeholder="Pencarian" id="keyword">
					
					<span class="input-group-btn">
					<button class="btn btn-primary" type="button" id="btn-cari">Search</button>
					<a href="" class="btn btn-danger">Reset</a>
					</span>
				</div>
				</div>
			
		   <!-- akhir -->
	    </div>
	 </div>
		<div class="card-body">
		<div class='row row-cols-1 row-cols-md-3 mb-4' id='jurnal-card'><div class='col mb-4'><div class='card bg-dark text-white'><div class='card-body text-white'><p class='card-text text-white'>Membuat tampilan login</p></div><small class='card-footer bg-transparent border-dark'>Diposting <b>16 jam lalu</b></small></div></div><div class='col mb-4'><div class='card bg-info text-white'><div class='card-body text-white'><p class='card-text text-white'>Membuat tampilan user dan tambah data</p></div><small class='card-footer bg-transparent border-info'>Diposting <b>kemarin</b></small></div></div><div class='col mb-4'><div class='card bg-info text-white'><div class='card-body text-white'><p class='card-text text-white'>Konsultasi rancangan tabel</p></div><small class='card-footer bg-transparent border-info'>Diposting <b>3 hari yang lalu</b></small></div></div></div>			<!-- akhir card -->
	<nav>
		<ul class="pagination justify-content-center">
			<li class="page-item">
				<a class="page-link" >Previous</a>
			</li>
			 
				<li class="page-item"><a class="page-link" href="?halaman=1">1</a></li>
								
			<li class="page-item">
				<a  class="page-link" >Next</a>
			</li>
		</ul>
	</nav>
	</div>
	</div>
	
	</div>
<script type="text/javascript">
	$(document).ready(function() {
		$('#btn-cari').on('click', function(){
		var keyword = $('#keyword').val();
		var jenis_user_ = "U";
		var iduser_ = "6";
		if (keyword == 0 ) {
		  alert('kosong!');
		}else{
		  // proceed with form submission
		  $.ajax({
			url: 'proses.php?aksi=cari_sewa',
			type: 'POST',
			data: {
				'keyword' : keyword,
				'jenis_user' : jenis_user_,
				'iduser' : iduser_,
				'bentuk' : 'card',
			},
			success: function(hasil){
				$('#sewa-card').html(hasil);
			}
		  });
		 }
		});
		
	});

</script>
</body>
</html>