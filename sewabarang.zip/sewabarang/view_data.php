<div class="container-fluid">
<div class="table-responsive">
<div class= "col-md-">
		<table class="table table-striped">
			<a href="tambah_data.php" class="btn btn-primary">Tambah</a>

		<hr>
			<thead>
			<tr>
				<th>No</th>
				<th>Nama Barang</th>
				<th>Tanggal</th>
				<th>Total</th>
				<th>Aksi</th>
			</tr>
			</thead>
			<tbody>
			
			<?php
				$no=1;
				foreach($data_data as $row){
			?>
						
					<tr>
						<td><?php echo $no; ?></td>
						<td><?php echo $row['nama_barang']; ?></td>
						<td><?php echo $row['tgl_sewa']; ?></td>
						<td><?php echo $row['total_sewa']; ?></td>
						<td>
						<a class="btn btn-dark" a href="proses_data.php?aksi=hapus_data&kode_barang=
							<?php echo $row['kode_barang']; ?>
							"onclick='return confirm("Apakah Yakin Ingin Menghapus?")'>Hapus</a>
							<?php
								$no++;
								}
							?>
						</td>
						
						</tr>
				</tbody>
			</table>
			
		</div>
		</div>
		